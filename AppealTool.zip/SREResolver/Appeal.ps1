﻿##
#Install-module PSExcel
#Get-command -module psexcel
##
#$path = "D:\Sentinel_onmicrosoft_01.xlsx"
#$record = new-object System.Collections.ArrayList

#$reviewedon = '2019-09-12T00:00:00.0000000Z'
[CmdletBinding()]
Param(
[string]$path,
[string]$ReviewdBy = $env:UserName+"@microsoft.com",
[string]$logpath = 'null'
)
$output = ""

if($logpath -eq 'null'){
Write-host "Provide log path,Quiting execution" -BackgroundColor Red
Write-host 'E.g.,  ".\Appeal.ps1 -path "D:\Anto\Script\Appeal\EscalateSentinel\DomainTriage.xlsx" -logpath "D:\Anto\Script\Appeal\EscalateSentinel\DomainTriage.log" ' -ForegroundColor Cyan
exit;
}

$items = Import-Excel -Path $path -StartRow 3
Write-Host $($items).count$
pause
$i=0;
foreach ($item in $items)
{
$UserID = $item.UserId
$decision = $item.Status
$updatedby=$item.ReviewdBy
$reviewedon=$item.ReviewedOn

##decision check
if(!($decision) -or $decision -eq $null) {
Write-Host "Excel status is empty"
"Status is Empty:$UserID" >> $logpath
}
elseif ($decision -eq "new"){
Write-Host "Decision status is New or pending for:"$UserID
"Pending status:$UserID" >> $logpath
}
else{
$decision = $decision
}

#reviewer chcek
if(!($updatedby) -or $updatedby -eq $null) {
$updatedby = $ReviewdBy}

#Review date check and main program
if(!($reviewedon) -or $reviewedon -eq $null){

    try{
        $output = .\SREAppealsResolver.exe $UserID $decision $updatedby 
        if ($output -notmatch "Successfully"){
        Write-host "Not Successfully updated:" $output 
        $UserID + $output  >> $logpath
        }else{
        $output +" "+ "by:$updatedby" +" "+ "on:$((Get-Date).ToUniversalTime())" 
        $output +" "+ "by:$updatedby" +" "+ "on:$((Get-Date).ToUniversalTime())"  >>$logpath}
        }
    catch{
        $UserID + $_.Exception.Message >> $logpath
        Write-Host $_.Exception.Message -ForegroundColor Green
        }
}
else{
     try{
         $output = .\SREAppealsResolver.exe $UserID $decision $updatedby $reviewedon
         if ($output -notmatch "Successfully"){
         Write-host "Not Successfully updated:" $output 
         $UserID + $output  >> $logpath
         }
         else{
         $output +" "+ "by:$updatedby" +" "+ "on:$reviewedon" 
         $output +" "+ "by:$updatedby" +" "+ "on:$reviewedon"  >>$logpath}
         }
     catch{
        $UserID + $_.Exception.Message >> $logpath
        Write-Host $_.Exception.Message -ForegroundColor Green
        } 
}

$i++
#$user.add($userid) | out-null #I don't want to see the output
Write-Host $i
}
 