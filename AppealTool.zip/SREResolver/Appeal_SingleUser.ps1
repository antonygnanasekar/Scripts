﻿ #Single user modification
 $ReviewdBy = $env:UserName+"@microsoft.com"
 $logpath = "D:\Anto\Script\Appeal\EscalateSentinel\resolver.log"
 $output = .\SREAppealsResolver.exe f5518e2c-a56d-4dee-83f6-3b2343a2dd4d approved $ReviewdBy 2019-11-01T00:00:00.0000000Z 
 if ($output -notmatch "Successfully")
 {
 Write-host "Not Successfully updated:" $output 
 $output + $UserID >> $logpath
 }
 else{
 $output
 $output >>$logpath}