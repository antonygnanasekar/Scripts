﻿##  contact antona
##  Script to Send Email escalation to sentinel Team to create Service-now ticket 
##  Import module Test-cred and Import-XLSX
##  cd <>\..\Appeal\
## .Example: EscalateSentinal -path "c:\appeal10-23.xlxs" -logpath "c:\appeal10-23log"
## to install modules run Install-Module ImportExcel


try{
##Import-Module .\Import-XLSX.ps1
Import-Module .\Test-Cred.psm1
}
catch { 
Write-Host $_
$_ | Out-File $logpath -Append -Width 1000
Break
}


function Escalate-Sentinel {
    [CmdletBinding()]
    [OutputType([String])] 
    Param ( 
        [Parameter( 
            Mandatory = $True
        )] 
        [Alias( 
            'excelpath'
        )] 
        [ValidateNotNull()] 
        $path,
        $logpath)
    
# Path Chcek
    if(!($logpath))
    {
    $logpath = ".\ProblemsSendingHotfixReport.log"
    }

# Credential Check
    Try
    {
    $Credentials = Get-Credential -UserName msdnm2b@microsoft.com -Message "SMTP" -ErrorAction Stop
    }
    Catch
    {
    $ErrorMsg = $_.Exception.Message
    Write-Warning "Failed to validate credentials: $ErrorMsg "
    "Failed to validate credentials: $ErrorMsg "| Out-File $logpath -Append -Width 1000
    Pause
    Break
    }
        $CredCheck = $Credentials  | Test-Cred
        If($CredCheck -ne "Authenticated")
        {
    Write-Warning "Credential validation failed"
   "Credential validation failed" | Out-File $logpath -Append -Width 1000
    pause
    Break
}


##Main 
## Import-XLSX Cmdlet required Import-Excel module to be install.
#$items = Import-XLSX -Path $path -RowStart 3
$items = Import-Excel -Path $path -StartRow 3
Write-Host $($items).count$
pause
$i=0;
foreach ($item in $items)
{
$UserID = $item.UserId
$SentinelSessionId = $item.SentinelSessionId 
$SubmittedOn = $item.SubmittedOn
$Reason = $item.Reason
$ErrorActionPreference = "Stop"
    try {
                if((!($UserID) -or ($UserID -eq 'null')) -or (($SentinelSessionId  -eq 'null') -or !($SentinelSessionId))){
        Write-Warning "Empty Value or Wrong Header!" 
        "UserID:$userID,SentinelSessionId:$SentinelSessionId or Both value are null in Excel!" | Out-File $logpath -Append -Width 1000
        continue;}
        #$date = $SubmittedOn.Remove(10,18)
        $date = $SubmittedOn.Substring(0, $SubmittedOn.lastIndexOf('T'))
        $output = [pscustomobject]@{
        IssueCode = 'P1-Standard escalation'
        UserID = $UserID
        SentinelSessionId = $SentinelSessionId
        SubmittedOn = $SubmittedOn
        Reason = $Reason
        Comments = 'Please review the attached user appeal'
        Createdby = $env:UserName
        }
            $frag = $output  | ConvertTo-Html -As LIST -Fragment -PreContent ‘<h3>Details</h3>’  | Out-String
            $head = @'
  
<style>
  body {
    font-family: "Arial";
    font-size: 15pt;
    color: #4C607B;
    }
  th, td { 
    border: 1px solid #e57300;
    border-collapse: collapse;
    padding: 5px;
    }  th {
    font-size: 1.2em;
    text-align: left;
    background-color: #003366;
    color: #ffffff;
    }
  td {
    color: #000000;
    }
  .even { background-color: #ffffff; }
  .odd { background-color: #bfbfbf; }
</style>
  
'@
            $EmailSubject = "MS Learn escalation ticket - Appeal on $date #SentinalID:$SentinelSessionId #Id:$UserID"
            $EmailBody = ConvertTo-Html -Head $head -PreContent “<h2>MS Learn escalations - User Appeal Submitted on $date</h2>” -PostContent $frag |Out-String 
            $messageParameters = @{From = "msdnm2b@microsoft.com"
                                   To = "sentesc@microsoft.com"
                                   SmtpServer = "smtp.office365.com" 
                                   Port = 587}
                                   #Write-Host $frag
                                  
            Send-MailMessage @messageParameters -Subject $EmailSubject -Body $EmailBody -BodyAsHtml -Credential $Credentials -UseSsl
            Write-Host "Successfully Sentinel escalation Sent: $UserID $SubmittedOn" -ForegroundColor Cyan
            "Successfully Sentinel escalation Sent: $UserID" | Out-File $logpath -Append -Width 1000
        }
    catch{
              Write-Host "Error Sending Mail:$UserID" -ForegroundColor Red
              "Error Sending Mail:$UserID"|Out-File $logpath -Append -Width 1000
              $_ |Out-File $logpath -Append -Width 1000
         }
         $i++;
         Write-Host $i
}

          Write-Host "Log Path:"$logpath 
}



